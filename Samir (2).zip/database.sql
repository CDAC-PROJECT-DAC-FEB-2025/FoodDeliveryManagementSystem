CREATE TABLE `order` (
  id BIGINT PRIMARY KEY,
  user_id BIGINT,
  status VARCHAR(32),
  total DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE order_item (
  id BIGINT PRIMARY KEY,
  order_id BIGINT,
  food_id BIGINT,
  quantity INT,
  price DECIMAL(10,2)
);
