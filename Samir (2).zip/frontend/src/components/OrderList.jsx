import React from 'react'
export default function OrderList(props){
  return <div className="card"><strong>OrderList</strong><div>Placeholder component.</div></div>
}
