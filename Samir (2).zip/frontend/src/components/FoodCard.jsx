import React from 'react'
export default function FoodCard(props){
  return <div className="card"><strong>FoodCard</strong><div>Placeholder component.</div></div>
}
