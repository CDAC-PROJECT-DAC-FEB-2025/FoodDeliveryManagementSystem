import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import './styles.css'
import Navbar from './components/Navbar.jsx'
// pages
import Home from './pages/Home.jsx'
import Menu from './pages/Menu.jsx'
import MyOrders from './pages/MyOrders.jsx'
const App = () => (
  <BrowserRouter>
    <Navbar />
    <div className="container">
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/menu" element={<Menu />} />
        <Route path="/myorders" element={<MyOrders />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </div>
  </BrowserRouter>
)
createRoot(document.getElementById('root')).render(<App />)
