import React from 'react'
export default function MyOrders(){return <div><h1>MyOrders</h1><p>Placeholder for MyOrders page.</p></div>}
