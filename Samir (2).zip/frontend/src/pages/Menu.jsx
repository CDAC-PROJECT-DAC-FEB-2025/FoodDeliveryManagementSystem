import React from 'react'
export default function Menu(){return <div><h1>Menu</h1><p>Placeholder for Menu page.</p></div>}
