package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/orders")
public class OrderController {
    @GetMapping("/mine") public Object myOrders() { return List.of(); }
    @PostMapping public Object placeOrder() { return Map.of("status","placed"); }
}