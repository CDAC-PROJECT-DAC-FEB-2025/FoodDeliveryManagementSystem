package com.example.foodapp.model; public class OrderItem {
    private Long id;
    private Long orderId;
    private Long foodId;
    private Integer quantity;
    private Double price;
}