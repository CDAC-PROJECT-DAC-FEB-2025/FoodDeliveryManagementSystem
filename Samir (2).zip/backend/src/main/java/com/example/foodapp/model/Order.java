package com.example.foodapp.model; public class Order {
    private Long id;
    private Long userId;
    private String status;
    private Double total;
}