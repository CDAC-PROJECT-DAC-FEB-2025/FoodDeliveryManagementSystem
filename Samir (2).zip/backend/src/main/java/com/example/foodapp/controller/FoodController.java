package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/foods")
public class FoodController {
    @GetMapping public Object listFoods() { return List.of(); }
    @GetMapping("/{id}) public Object getFood(@PathVariable Long id) { return Map.of("id",id); }
}