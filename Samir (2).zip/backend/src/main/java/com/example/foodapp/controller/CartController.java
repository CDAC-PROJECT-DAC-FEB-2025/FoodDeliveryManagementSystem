package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/cart")
public class CartController {
    @GetMapping public Object getCart() { return List.of(); }
    @PostMapping public Object addToCart() { return Map.of("message","added"); }
    @DeleteMapping public Object removeFromCart() { return Map.of("message","removed"); }
}