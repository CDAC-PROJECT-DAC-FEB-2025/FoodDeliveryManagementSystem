CREATE TABLE food (
  id BIGINT PRIMARY KEY,
  name VARCHAR(120),
  price DECIMAL(10,2),
  category VARCHAR(80),
  description TEXT
);
CREATE TABLE `order` (
  id BIGINT PRIMARY KEY,
  user_id BIGINT,
  status VARCHAR(32),
  total DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
