import React from 'react'
export default function ReportCharts(props){
  return <div className="card"><strong>ReportCharts</strong><div>Placeholder component.</div></div>
}
