import React from 'react'
export default function FoodForm(props){
  return <div className="card"><strong>FoodForm</strong><div>Placeholder component.</div></div>
}
