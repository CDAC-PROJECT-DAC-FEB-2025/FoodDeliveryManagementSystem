import React from 'react'
export default function AdminNavbar(props){
  return <div className="card"><strong>AdminNavbar</strong><div>Placeholder component.</div></div>
}
