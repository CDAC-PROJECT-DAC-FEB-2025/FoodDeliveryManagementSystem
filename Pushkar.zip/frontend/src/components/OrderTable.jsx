import React from 'react'
export default function OrderTable(props){
  return <div className="card"><strong>OrderTable</strong><div>Placeholder component.</div></div>
}
