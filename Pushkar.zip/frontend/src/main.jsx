import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import './styles.css'
import Navbar from './components/Navbar.jsx'
// pages
import Dashboard from './pages/Dashboard.jsx'
import ManageFoods from './pages/ManageFoods.jsx'
import ViewOrders from './pages/ViewOrders.jsx'
import Reports from './pages/Reports.jsx'
const App = () => (
  <BrowserRouter>
    <Navbar />
    <div className="container">
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/managefoods" element={<ManageFoods />} />
        <Route path="/vieworders" element={<ViewOrders />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </div>
  </BrowserRouter>
)
createRoot(document.getElementById('root')).render(<App />)
