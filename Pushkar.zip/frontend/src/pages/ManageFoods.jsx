import React from 'react'
export default function ManageFoods(){return <div><h1>ManageFoods</h1><p>Placeholder for ManageFoods page.</p></div>}
