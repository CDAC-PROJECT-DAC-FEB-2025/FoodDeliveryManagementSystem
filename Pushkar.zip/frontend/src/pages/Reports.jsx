import React from 'react'
export default function Reports(){return <div><h1>Reports</h1><p>Placeholder for Reports page.</p></div>}
