package com.example.foodapp.service; import org.springframework.stereotype.Service; import java.util.*;
@Service public class FoodService { public Object create(){ return Map.of(); } }