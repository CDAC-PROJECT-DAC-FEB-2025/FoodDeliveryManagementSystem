package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/admin/orders")
public class OrderController {
    @GetMapping public Object all() { return List.of(); }
    @PatchMapping("/{id}/status") public Object updateStatus(@PathVariable Long id, @RequestBody Map<String,String> req) { return Map.of("id",id,"status",req.getOrDefault("status","pending")); }
}