package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/admin/foods")
public class FoodController {
    @PostMapping public Object add() { return Map.of("status","created"); }
    @PutMapping("/{id}) public Object update(@PathVariable Long id) { return Map.of("status","updated","id",id); }
    @DeleteMapping("/{id}) public Object delete(@PathVariable Long id) { return Map.of("status","deleted","id",id); }
}