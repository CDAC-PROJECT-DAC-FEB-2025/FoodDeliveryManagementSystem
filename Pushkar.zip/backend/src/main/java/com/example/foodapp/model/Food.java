package com.example.foodapp.model; public class Food {
    private Long id;
    private String name;
    private Double price;
    private String category;
}