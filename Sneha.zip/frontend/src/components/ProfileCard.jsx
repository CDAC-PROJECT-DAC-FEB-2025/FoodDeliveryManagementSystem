import React from 'react'
export default function ProfileCard(props){
  return <div className="card"><strong>ProfileCard</strong><div>Placeholder component.</div></div>
}
