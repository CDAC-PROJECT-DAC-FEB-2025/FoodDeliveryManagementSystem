import React from 'react'
export default function CartItem(props){
  return <div className="card"><strong>CartItem</strong><div>Placeholder component.</div></div>
}
