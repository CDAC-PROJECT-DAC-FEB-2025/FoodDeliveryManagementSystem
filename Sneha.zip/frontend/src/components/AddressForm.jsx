import React from 'react'
export default function AddressForm(props){
  return <div className="card"><strong>AddressForm</strong><div>Placeholder component.</div></div>
}
