import React from 'react'
export default function AuthForms(props){
  return <div className="card"><strong>AuthForms</strong><div>Placeholder component.</div></div>
}
