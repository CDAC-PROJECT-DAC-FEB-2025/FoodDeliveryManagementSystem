import React from 'react'
export default function Footer(props){
  return <div className="card"><strong>Footer</strong><div>Placeholder component.</div></div>
}
