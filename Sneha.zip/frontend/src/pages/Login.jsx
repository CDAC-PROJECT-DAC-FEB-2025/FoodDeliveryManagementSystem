import React from 'react'
export default function Login(){return <div><h1>Login</h1><p>Placeholder for Login page.</p></div>}
