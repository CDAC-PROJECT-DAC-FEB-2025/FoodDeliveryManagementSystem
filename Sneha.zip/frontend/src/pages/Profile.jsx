import React from 'react'
export default function Profile(){return <div><h1>Profile</h1><p>Placeholder for Profile page.</p></div>}
