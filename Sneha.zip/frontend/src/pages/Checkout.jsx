import React from 'react'
export default function Checkout(){return <div><h1>Checkout</h1><p>Placeholder for Checkout page.</p></div>}
