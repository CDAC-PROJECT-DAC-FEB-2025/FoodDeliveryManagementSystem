CREATE TABLE user (
  id BIGINT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(120) UNIQUE,
  password_hash VARCHAR(255)
);
CREATE TABLE address (
  id BIGINT PRIMARY KEY,
  user_id BIGINT,
  street VARCHAR(255),
  city VARCHAR(100),
  zip VARCHAR(20)
);
