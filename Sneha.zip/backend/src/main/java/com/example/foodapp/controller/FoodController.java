package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/foods")
public class FoodController {
    @GetMapping public Object listFoods() { return List.of(); }
}