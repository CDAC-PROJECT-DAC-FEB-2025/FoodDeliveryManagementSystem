package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/auth")
public class AuthController {
    @PostMapping("/register") public Object register() { return Map.of("status","registered"); }
    @PostMapping("/login") public Object login() { return Map.of("token","demo"); }
}