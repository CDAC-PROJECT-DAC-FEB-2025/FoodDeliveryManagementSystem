package com.example.foodapp.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/orders")
public class OrderController {
    @PostMapping("/{id}/cancel") public Object cancel(@PathVariable Long id) { return Map.of("status","cancelled","id",id); }
    @GetMapping("/{id}) public Object details(@PathVariable Long id) { return Map.of("id",id); }
}